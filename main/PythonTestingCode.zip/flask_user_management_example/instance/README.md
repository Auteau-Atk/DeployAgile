# Instance Folder

## Purpose

The `instance` folder is used to store run-time data, including log files and database files (SQLite).
